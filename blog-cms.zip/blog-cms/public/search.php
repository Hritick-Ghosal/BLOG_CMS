<?php
include '../config/constants.php';
include '../config/session.php';
include '../config/db.php';

$search_query = isset($_GET['q']) ? trim($_GET['q']) : '';
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$posts_per_page = 6;
$offset = ($page - 1) * $posts_per_page;

$results = [];
$total_posts = 0;
$total_pages = 0;

if (!empty($search_query) && strlen($search_query) >= 2) {
    $search_term = '%' . $conn->real_escape_string($search_query) . '%';
    
    // Search query with author info
    $query = "
        SELECT 
            p.id,
            p.title,
            p.slug,
            p.excerpt,
            p.featured_image,
            p.views,
            p.published_at,
            u.id as author_id,
            u.username,
            u.full_name
        FROM posts p
        JOIN users u ON p.author_id = u.id
        WHERE p.status = 'published' AND (
            p.title LIKE ? 
            OR p.content LIKE ? 
            OR p.excerpt LIKE ?
            OR u.full_name LIKE ?
            OR u.username LIKE ?
        )
        ORDER BY p.published_at DESC
        LIMIT ? OFFSET ?
    ";
    
    $stmt = $conn->prepare($query);
    if (!$stmt) {
        die("Prepare failed: " . $conn->error);
    }
    
    $stmt->bind_param("sssssii", $search_term, $search_term, $search_term, $search_term, $search_term, $posts_per_page, $offset);
    $stmt->execute();
    $result = $stmt->get_result();
    
    while ($row = $result->fetch_assoc()) {
        $results[] = $row;
    }
    $stmt->close();
    
    // Get total count
    $count_query = "
        SELECT COUNT(*) as count FROM posts p
        JOIN users u ON p.author_id = u.id
        WHERE p.status = 'published' AND (
            p.title LIKE ? 
            OR p.content LIKE ? 
            OR p.excerpt LIKE ?
            OR u.full_name LIKE ?
            OR u.username LIKE ?
        )
    ";
    
    $count_stmt = $conn->prepare($count_query);
    $count_stmt->bind_param("sssss", $search_term, $search_term, $search_term, $search_term, $search_term);
    $count_stmt->execute();
    $count_result = $count_stmt->get_result();
    $total_posts = $count_result->fetch_assoc()['count'];
    $total_pages = ceil($total_posts / $posts_per_page);
    $count_stmt->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Search Results — Blog</title>
    <link rel="stylesheet" href="../assets/css/styles.css">
</head>
<body class="has-navbar">
    <!-- Navigation -->
    <nav class="top-navbar">
        <h1>📝 Blog</h1>
        <div class="top-navbar-menu">
            <a href="index.php">🏠 Home</a>
            <?php if (!isset($_SESSION['user_id'])): ?>
                <a href="../login.php" class="btn btn-login">🔐 Login</a>
            <?php else: ?>
                <a href="<?php echo $_SESSION['user_role'] === 'admin' ? '../admin/dashboard.php' : '../author/dashboard.php'; ?>" class="btn btn-login">📊 Dashboard</a>
                <a href="../login.php?logout=1" class="btn btn-secondary">🚪 Logout</a>
            <?php endif; ?>
        </div>
    </nav>

    <!-- Main Content -->
    <div class="public-container">
        <!-- Search Box -->
        <div class="search-box">
            <h2>🔍 Search Articles</h2>
            <form method="GET" action="search.php">
                <input type="text" name="q" value="<?php echo htmlspecialchars($search_query); ?>" placeholder="Search for posts, topics, or authors...">
                <button type="submit">🔎 Search</button>
            </form>
        </div>

        <!-- Results -->
        <?php if (!empty($search_query)): ?>
            <?php if (count($results) > 0): ?>
            <div style="margin-bottom: 24px; padding: 16px; background: #e0e7ff; border-radius: 10px; color: #3730a3; font-weight: 700;">
                🔎 Found <strong><?php echo $total_posts; ?></strong> result(s) for "<strong><?php echo htmlspecialchars($search_query); ?></strong>"
            </div>

            <div class="posts-grid">
                <?php foreach ($results as $post): ?>
                <div class="post-card">
                    <a href="post.php?slug=<?php echo urlencode($post['slug']); ?>">
                        <?php if (!empty($post['featured_image'])): ?>
                            <img src="../uploads/posts/<?php echo htmlspecialchars($post['featured_image']); ?>" alt="<?php echo htmlspecialchars($post['title']); ?>" class="post-image">
                        <?php else: ?>
                            <div class="post-image" style="background: linear-gradient(135deg, #e0e7ff, #f3e8ff); display: flex; align-items: center; justify-content: center; color: #6366f1; font-weight: 800;">
                                📝 No Image
                            </div>
                        <?php endif; ?>
                        
                        <div class="post-content">
                            <div class="post-meta">
                                <span>✍️ <?php echo htmlspecialchars($post['full_name'] ?? $post['username']); ?></span>
                                <span>📅 <?php echo date('M d, Y', strtotime($post['published_at'])); ?></span>
                                <span>👁️ <?php echo number_format($post['views']); ?> views</span>
                            </div>
                            <h2><?php echo htmlspecialchars($post['title']); ?></h2>
                            <p><?php echo htmlspecialchars(substr($post['excerpt'] ?? $post['title'], 0, 150)) . '...'; ?></p>
                            <span class="read-more">Read Article →</span>
                        </div>
                    </a>
                </div>
                <?php endforeach; ?>
            </div>

            <!-- Pagination -->
            <?php if ($total_pages > 1): ?>
            <div class="pagination">
                <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                    <?php if ($i == $page): ?>
                        <span class="active"><?php echo $i; ?></span>
                    <?php else: ?>
                        <a href="search.php?q=<?php echo urlencode($search_query); ?>&page=<?php echo $i; ?>"><?php echo $i; ?></a>
                    <?php endif; ?>
                <?php endfor; ?>
            </div>
            <?php endif; ?>

            <?php else: ?>
            <!-- No Results -->
            <div class="no-posts">
                <h2>😕 No Results Found</h2>
                <p>No posts found matching "<strong><?php echo htmlspecialchars($search_query); ?></strong>". Try different keywords or browse all articles.</p>
                <a href="index.php" class="btn btn-primary btn-lg" style="margin-top: 16px;">🏠 Back to Home</a>
            </div>
            <?php endif; ?>
        <?php else: ?>
            <!-- Empty State -->
            <div class="no-posts">
                <h2>🔍 Start Searching</h2>
                <p>Enter keywords in the search box above to find posts by title, content, or author.</p>
            </div>
        <?php endif; ?>
    </div>

    <!-- Footer -->
    <footer class="footer">
        <p>&copy; 2025 My Professional Blog. All rights reserved.</p>
        <p>Built with Modern Blog CMS™</p>
    </footer>
</body>
</html>
