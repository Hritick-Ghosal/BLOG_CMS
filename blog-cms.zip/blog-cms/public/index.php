<?php
include '../config/db.php';
include '../config/constants.php';

$page = $_GET['page'] ?? 1;
$page = max(1, intval($page));
$offset = ($page - 1) * POSTS_PER_PAGE;

$query = "
    SELECT p.id, p.title, p.slug, p.excerpt, p.featured_image, p.views, p.published_at, u.username 
    FROM posts p 
    JOIN users u ON p.author_id = u.id 
    WHERE p.status = 'published' 
    ORDER BY p.published_at DESC 
    LIMIT ? OFFSET ?
";

$stmt = $conn->prepare($query);
$per_page = POSTS_PER_PAGE;
$stmt->bind_param("ii", $per_page, $offset);
$stmt->execute();
$result = $stmt->get_result();

$total_query = $conn->query("SELECT COUNT(*) as count FROM posts WHERE status = 'published'");
$total_posts = $total_query->fetch_assoc()['count'];
$total_pages = ceil($total_posts / POSTS_PER_PAGE);

$stmt->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo APP_NAME; ?> - Home</title>
    <link rel="stylesheet" href="../assets/css/styles.css">
    <link rel="stylesheet" href="../assets/css/styles.css">
    <style>
        .post-image {
            width: 100%;
            height: 250px;
            object-fit: cover;
            border-radius: 8px 8px 0 0;
            background: #f0f0f0;
        }
    </style>
</head>
<body>
    <div class="top-navbar">
        <h1><?php echo APP_NAME; ?></h1>
        <div class="top-navbar-menu">
            <a href="index.php">Home</a>
            <a href="search.php">Search</a>
            <a href="../login.php" class="btn-login">Login</a>
        </div>
    </div>
    
    <div class="header-banner">
        <h1><?php echo APP_NAME; ?></h1>
        <p>Discover amazing stories, insights, and ideas from talented authors</p>
    </div>
    
    <div class="public-container">
        <div class="search-box">
            <h2>Search Posts</h2>
            <form method="GET" action="search.php">
                <input type="text" name="q" placeholder="Search posts by keywords..." required>
                <button type="submit">Search</button>
            </form>
        </div>
        
        <?php if ($result->num_rows > 0): ?>
            <div class="posts-grid">
                <?php while ($post = $result->fetch_assoc()): ?>
                    <div class="post-card">
                        <a href="post.php?slug=<?php echo $post['slug']; ?>">
                            <!-- Display Featured Image -->
                            <?php if (!empty($post['featured_image'])): ?>
                                <img src="../uploads/posts/<?php echo htmlspecialchars($post['featured_image']); ?>" alt="<?php echo htmlspecialchars($post['title']); ?>" class="post-image">
                            <?php else: ?>
                                <div class="post-image" style="display: flex; align-items: center; justify-content: center; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; font-size: 14px;">
                                    No Image
                                </div>
                            <?php endif; ?>
                            
                            <div class="post-content">
                                <div class="post-meta">
                                    <span>By <?php echo htmlspecialchars($post['username']); ?></span>
                                    <span><?php echo date('M d, Y', strtotime($post['published_at'])); ?></span>
                                    <span><?php echo $post['views']; ?> views</span>
                                </div>
                                <h2><?php echo htmlspecialchars($post['title']); ?></h2>
                                <p><?php echo htmlspecialchars($post['excerpt']); ?></p>
                                <span class="read-more">Read More →</span>
                            </div>
                        </a>
                    </div>
                <?php endwhile; ?>
            </div>
            
            <?php if ($total_pages > 1): ?>
                <div class="pagination">
                    <?php if ($page > 1): ?>
                        <a href="?page=1">First</a>
                        <a href="?page=<?php echo $page - 1; ?>">← Previous</a>
                    <?php endif; ?>
                    
                    <?php for ($i = max(1, $page - 2); $i <= min($total_pages, $page + 2); $i++): ?>
                        <?php if ($i == $page): ?>
                            <span class="active"><?php echo $i; ?></span>
                        <?php else: ?>
                            <a href="?page=<?php echo $i; ?>"><?php echo $i; ?></a>
                        <?php endif; ?>
                    <?php endfor; ?>
                    
                    <?php if ($page < $total_pages): ?>
                        <a href="?page=<?php echo $page + 1; ?>">Next →</a>
                        <a href="?page=<?php echo $total_pages; ?>">Last</a>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        <?php else: ?>
            <div class="no-posts">
                <h2>No Posts Yet</h2>
                <p>Check back soon for amazing content!</p>
            </div>
        <?php endif; ?>
    </div>
    
    <div class="footer">
        <p>&copy; <?php echo date('Y'); ?> <?php echo APP_NAME; ?>. All rights reserved.</p>
        <p>Powered by PHP & MySQL</p>
    </div>
</body>
</html>
