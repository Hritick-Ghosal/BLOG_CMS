<?php
/**
 * Reactions API Handler
 * Handles likes and dislikes for blog posts
 */

error_reporting(E_ALL);
ini_set('display_errors', 0);

include '../../config/db.php';
include '../../config/constants.php';

header('Content-Type: application/json');

// Log errors to file
function log_error($message) {
    $log_file = '../../logs/reactions_error.log';
    if (!is_dir('../../logs')) {
        @mkdir('../../logs', 0755, true);
    }
    @file_put_contents($log_file, date('Y-m-d H:i:s') . ' - ' . $message . PHP_EOL, FILE_APPEND);
}

try {
    // Get parameters
    $action = $_GET['action'] ?? '';
    $post_id = intval($_GET['post_id'] ?? 0);
    $reaction = $_GET['reaction'] ?? '';
    $ip_address = $_SERVER['REMOTE_ADDR'];
    
    // Debug logging
    log_error("Request: action=$action, post_id=$post_id, reaction=$reaction, ip=$ip_address");
    
    // Validate input - reaction is only needed for toggle, not for get
    if (empty($action) || empty($post_id)) {
        throw new Exception('Invalid request: action and post_id required');
    }
    
    // For GET action, reaction is not needed
    if ($action === 'toggle' && !in_array($reaction, ['like', 'dislike'])) {
        throw new Exception('Invalid reaction: must be "like" or "dislike"');
    }
    
    // Verify post exists
    $post_check = $conn->prepare("SELECT id FROM posts WHERE id = ? AND status = 'published'");
    if (!$post_check) {
        throw new Exception('DB Error: ' . $conn->error);
    }
    
    $post_check->bind_param("i", $post_id);
    if (!$post_check->execute()) {
        throw new Exception('Query Error: ' . $post_check->error);
    }
    
    if ($post_check->get_result()->num_rows === 0) {
        throw new Exception('Post not found');
    }
    $post_check->close();
    
    // ============================================================
    // TOGGLE ACTION - Add, update, or remove reaction
    // ============================================================
    if ($action === 'toggle') {
        // Check if user already reacted
        $check_stmt = $conn->prepare("
            SELECT id, reaction FROM post_reactions 
            WHERE post_id = ? AND ip_address = ?
        ");
        
        if (!$check_stmt) {
            throw new Exception('DB Error: ' . $conn->error);
        }
        
        $check_stmt->bind_param("is", $post_id, $ip_address);
        if (!$check_stmt->execute()) {
            throw new Exception('Query Error: ' . $check_stmt->error);
        }
        
        $check_result = $check_stmt->get_result();
        
        // If user already reacted
        if ($check_result->num_rows > 0) {
            $existing = $check_result->fetch_assoc();
            
            // Same reaction - remove it
            if ($existing['reaction'] === $reaction) {
                $delete_stmt = $conn->prepare("
                    DELETE FROM post_reactions 
                    WHERE post_id = ? AND ip_address = ?
                ");
                
                if (!$delete_stmt) {
                    throw new Exception('DB Error: ' . $conn->error);
                }
                
                $delete_stmt->bind_param("is", $post_id, $ip_address);
                if (!$delete_stmt->execute()) {
                    throw new Exception('Delete Error: ' . $delete_stmt->error);
                }
                $delete_stmt->close();
                
                // Update count
                if ($reaction === 'like') {
                    $update_stmt = $conn->prepare("UPDATE posts SET likes = GREATEST(likes - 1, 0) WHERE id = ?");
                } else {
                    $update_stmt = $conn->prepare("UPDATE posts SET dislikes = GREATEST(dislikes - 1, 0) WHERE id = ?");
                }
                
                if (!$update_stmt) {
                    throw new Exception('DB Error: ' . $conn->error);
                }
                
                $update_stmt->bind_param("i", $post_id);
                if (!$update_stmt->execute()) {
                    throw new Exception('Update Error: ' . $update_stmt->error);
                }
                $update_stmt->close();
                
                log_error("Removed reaction: post=$post_id, reaction=$reaction, ip=$ip_address");
                
                http_response_code(200);
                die(json_encode([
                    'success' => true,
                    'action' => 'removed',
                    'message' => 'Reaction removed'
                ]));
            } 
            // Different reaction - change it
            else {
                $old_reaction = $existing['reaction'];
                
                // Update reaction
                $update_reaction_stmt = $conn->prepare("
                    UPDATE post_reactions 
                    SET reaction = ? 
                    WHERE post_id = ? AND ip_address = ?
                ");
                
                if (!$update_reaction_stmt) {
                    throw new Exception('DB Error: ' . $conn->error);
                }
                
                $update_reaction_stmt->bind_param("sis", $reaction, $post_id, $ip_address);
                if (!$update_reaction_stmt->execute()) {
                    throw new Exception('Update Error: ' . $update_reaction_stmt->error);
                }
                $update_reaction_stmt->close();
                
                // Decrement old reaction
                if ($old_reaction === 'like') {
                    $dec_stmt = $conn->prepare("UPDATE posts SET likes = GREATEST(likes - 1, 0) WHERE id = ?");
                } else {
                    $dec_stmt = $conn->prepare("UPDATE posts SET dislikes = GREATEST(dislikes - 1, 0) WHERE id = ?");
                }
                
                if (!$dec_stmt) {
                    throw new Exception('DB Error: ' . $conn->error);
                }
                
                $dec_stmt->bind_param("i", $post_id);
                if (!$dec_stmt->execute()) {
                    throw new Exception('Decrement Error: ' . $dec_stmt->error);
                }
                $dec_stmt->close();
                
                // Increment new reaction
                if ($reaction === 'like') {
                    $inc_stmt = $conn->prepare("UPDATE posts SET likes = likes + 1 WHERE id = ?");
                } else {
                    $inc_stmt = $conn->prepare("UPDATE posts SET dislikes = dislikes + 1 WHERE id = ?");
                }
                
                if (!$inc_stmt) {
                    throw new Exception('DB Error: ' . $conn->error);
                }
                
                $inc_stmt->bind_param("i", $post_id);
                if (!$inc_stmt->execute()) {
                    throw new Exception('Increment Error: ' . $inc_stmt->error);
                }
                $inc_stmt->close();
                
                log_error("Changed reaction: post=$post_id, old=$old_reaction, new=$reaction, ip=$ip_address");
                
                http_response_code(200);
                die(json_encode([
                    'success' => true,
                    'action' => 'changed',
                    'message' => 'Reaction changed'
                ]));
            }
        } 
        // New reaction - add it
        else {
            $insert_stmt = $conn->prepare("
                INSERT INTO post_reactions (post_id, ip_address, reaction) 
                VALUES (?, ?, ?)
            ");
            
            if (!$insert_stmt) {
                throw new Exception('DB Error: ' . $conn->error);
            }
            
            $insert_stmt->bind_param("iss", $post_id, $ip_address, $reaction);
            if (!$insert_stmt->execute()) {
                throw new Exception('Insert Error: ' . $insert_stmt->error);
            }
            $insert_stmt->close();
            
            // Increment count
            if ($reaction === 'like') {
                $update_stmt = $conn->prepare("UPDATE posts SET likes = likes + 1 WHERE id = ?");
            } else {
                $update_stmt = $conn->prepare("UPDATE posts SET dislikes = dislikes + 1 WHERE id = ?");
            }
            
            if (!$update_stmt) {
                throw new Exception('DB Error: ' . $conn->error);
            }
            
            $update_stmt->bind_param("i", $post_id);
            if (!$update_stmt->execute()) {
                throw new Exception('Update Error: ' . $update_stmt->error);
            }
            $update_stmt->close();
            
            log_error("Added reaction: post=$post_id, reaction=$reaction, ip=$ip_address");
            
            http_response_code(200);
            die(json_encode([
                'success' => true,
                'action' => 'added',
                'message' => 'Reaction added'
            ]));
        }
        
        $check_stmt->close();
    }
    
    // ============================================================
    // GET ACTION - Retrieve current reactions
    // ============================================================
    if ($action === 'get') {
        // Get current user's reaction
        $user_stmt = $conn->prepare("
            SELECT reaction FROM post_reactions 
            WHERE post_id = ? AND ip_address = ?
        ");
        
        if (!$user_stmt) {
            throw new Exception('DB Error: ' . $conn->error);
        }
        
        $user_stmt->bind_param("is", $post_id, $ip_address);
        if (!$user_stmt->execute()) {
            throw new Exception('Query Error: ' . $user_stmt->error);
        }
        
        $user_result = $user_stmt->get_result();
        
        $user_reaction = null;
        if ($user_result->num_rows > 0) {
            $user_reaction = $user_result->fetch_assoc()['reaction'];
        }
        
        $user_stmt->close();
        
        // Get post counts
        $post_stmt = $conn->prepare("SELECT likes, dislikes FROM posts WHERE id = ?");
        
        if (!$post_stmt) {
            throw new Exception('DB Error: ' . $conn->error);
        }
        
        $post_stmt->bind_param("i", $post_id);
        if (!$post_stmt->execute()) {
            throw new Exception('Query Error: ' . $post_stmt->error);
        }
        
        $post_result = $post_stmt->get_result();
        $post_data = $post_result->fetch_assoc();
        
        if (!$post_data) {
            throw new Exception('Post data not found');
        }
        
        $post_stmt->close();
        
        log_error("Get reactions: post=$post_id, user_reaction=$user_reaction, likes=" . $post_data['likes'] . ", dislikes=" . $post_data['dislikes']);
        
        http_response_code(200);
        die(json_encode([
            'success' => true,
            'user_reaction' => $user_reaction,
            'likes' => intval($post_data['likes'] ?? 0),
            'dislikes' => intval($post_data['dislikes'] ?? 0)
        ]));
    }
    
    throw new Exception('Unknown action: ' . $action);
    
} catch (Exception $e) {
    log_error('Exception: ' . $e->getMessage());
    
    http_response_code(400);
    die(json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]));
}
?>
