<?php
/**
 * Comments API Handler
 * Handles adding and retrieving comments for blog posts
 */

include '../../config/db.php';
include '../../config/constants.php';

// Set JSON response header
header('Content-Type: application/json');

// Get parameters
$action = $_GET['action'] ?? '';
$post_id = intval($_GET['post_id'] ?? 0);

// Validate post_id
if (empty($post_id)) {
    die(json_encode([
        'success' => false,
        'error' => 'Invalid post ID'
    ]));
}

/**
 * ADD ACTION - Submit new comment
 */
if ($action === 'add') {
    $author_name = trim($_POST['author_name'] ?? '');
    $author_email = trim($_POST['author_email'] ?? '');
    $content = trim($_POST['content'] ?? '');
    $ip_address = $_SERVER['REMOTE_ADDR'];
    
    // Validate inputs
    if (empty($author_name)) {
        die(json_encode([
            'success' => false,
            'error' => 'Name is required'
        ]));
    }
    
    if (empty($author_email)) {
        die(json_encode([
            'success' => false,
            'error' => 'Email is required'
        ]));
    }
    
    if (!filter_var($author_email, FILTER_VALIDATE_EMAIL)) {
        die(json_encode([
            'success' => false,
            'error' => 'Invalid email format'
        ]));
    }
    
    if (empty($content)) {
        die(json_encode([
            'success' => false,
            'error' => 'Comment cannot be empty'
        ]));
    }
    
    if (strlen($author_name) > 100) {
        die(json_encode([
            'success' => false,
            'error' => 'Name too long (max 100 characters)'
        ]));
    }
    
    if (strlen($content) > 1000) {
        die(json_encode([
            'success' => false,
            'error' => 'Comment too long (max 1000 characters)'
        ]));
    }
    
    // Verify post exists
    $post_check = $conn->prepare("SELECT id FROM posts WHERE id = ? AND status = 'published'");
    $post_check->bind_param("i", $post_id);
    $post_check->execute();
    if ($post_check->get_result()->num_rows === 0) {
        die(json_encode([
            'success' => false,
            'error' => 'Post not found'
        ]));
    }
    $post_check->close();
    
    // Sanitize inputs
    $author_name = htmlspecialchars($author_name, ENT_QUOTES, 'UTF-8');
    $author_email = htmlspecialchars($author_email, ENT_QUOTES, 'UTF-8');
    $content = htmlspecialchars($content, ENT_QUOTES, 'UTF-8');
    
    // Insert comment
    $insert_stmt = $conn->prepare("
        INSERT INTO post_comments (post_id, author_name, author_email, content, ip_address, status) 
        VALUES (?, ?, ?, ?, ?, 'pending')
    ");
    
    if (!$insert_stmt) {
        die(json_encode([
            'success' => false,
            'error' => 'Database error: ' . $conn->error
        ]));
    }
    
    $insert_stmt->bind_param("issss", $post_id, $author_name, $author_email, $content, $ip_address);
    
    if ($insert_stmt->execute()) {
        $comment_id = $conn->insert_id;
        $insert_stmt->close();
        
        die(json_encode([
            'success' => true,
            'message' => 'Comment submitted! It will appear after admin approval.',
            'comment_id' => $comment_id
        ]));
    } else {
        die(json_encode([
            'success' => false,
            'error' => 'Failed to submit comment: ' . $insert_stmt->error
        ]));
    }
    
    $insert_stmt->close();
}

/**
 * GET ACTION - Retrieve approved comments
 */
if ($action === 'get') {
    $comments_stmt = $conn->prepare("
        SELECT id, author_name, content, created_at 
        FROM post_comments 
        WHERE post_id = ? AND status = 'approved' 
        ORDER BY created_at DESC
    ");
    
    if (!$comments_stmt) {
        die(json_encode([
            'success' => false,
            'error' => 'Database error: ' . $conn->error
        ]));
    }
    
    $comments_stmt->bind_param("i", $post_id);
    $comments_stmt->execute();
    $comments_result = $comments_stmt->get_result();
    
    $comments = [];
    while ($comment = $comments_result->fetch_assoc()) {
        $comments[] = [
            'id' => intval($comment['id']),
            'author' => htmlspecialchars($comment['author_name']),
            'content' => htmlspecialchars($comment['content']),
            'date' => date('M d, Y H:i', strtotime($comment['created_at']))
        ];
    }
    
    $comments_stmt->close();
    
    die(json_encode([
        'success' => true,
        'comments' => $comments,
        'count' => count($comments)
    ]));
}

// Unknown action
die(json_encode([
    'success' => false,
    'error' => 'Unknown action'
]));
?>
