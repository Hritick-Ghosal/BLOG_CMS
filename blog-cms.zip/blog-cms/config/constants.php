<?php
define('APP_NAME', 'Blog CMS');
define('APP_URL', 'http://localhost/blog-cms');
define('POSTS_PER_PAGE', 10);
define('SESSION_TIMEOUT', 3600);
define('PASSWORD_MIN_LENGTH', 8);
define('ADMIN_ROLE', 'admin');
define('AUTHOR_ROLE', 'author');
?>