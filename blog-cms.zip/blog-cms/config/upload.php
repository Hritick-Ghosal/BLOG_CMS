<?php
// Image Upload Handler

class ImageUploader {
    private $upload_dir = '../uploads/posts/';
    private $allowed_types = ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
    private $max_size = 5242880; // 5MB in bytes
    private $allowed_extensions = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
    
    public function __construct() {
        if (!is_dir($this->upload_dir)) {
            mkdir($this->upload_dir, 0755, true);
        }
    }
    
    public function upload($file) {
        // Validate file exists
        if (!isset($file) || $file['error'] !== UPLOAD_ERR_OK) {
            return ['success' => false, 'error' => 'No file uploaded or file error'];
        }
        
        // Validate file size
        if ($file['size'] > $this->max_size) {
            return ['success' => false, 'error' => 'File size exceeds 5MB limit'];
        }
        
        // Validate file type
        if (!in_array($file['type'], $this->allowed_types)) {
            return ['success' => false, 'error' => 'Invalid file type. Only JPG, PNG, GIF, and WebP allowed'];
        }
        
        // Get file extension
        $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        if (!in_array($ext, $this->allowed_extensions)) {
            return ['success' => false, 'error' => 'Invalid file extension'];
        }
        
        // Generate unique filename
        $filename = 'post_' . time() . '_' . uniqid() . '.' . $ext;
        $filepath = $this->upload_dir . $filename;
        
        // Move uploaded file
        if (move_uploaded_file($file['tmp_name'], $filepath)) {
            return ['success' => true, 'filename' => $filename, 'path' => $filepath];
        } else {
            return ['success' => false, 'error' => 'Failed to upload file'];
        }
    }
    
    public function delete($filename) {
        if (!empty($filename)) {
            $filepath = $this->upload_dir . $filename;
            if (file_exists($filepath)) {
                return unlink($filepath);
            }
        }
        return false;
    }
    
    public function getUploadUrl($filename) {
        return '../uploads/posts/' . $filename;
    }
}
?>
