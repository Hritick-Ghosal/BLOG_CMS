<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
    header("X-Content-Type-Options: nosniff");
    header("X-Frame-Options: SAMEORIGIN");
    header("X-XSS-Protection: 1; mode=block");
}

if (isset($_SESSION['user_id'])) {
    $current_time = time();
    $login_time = isset($_SESSION['login_time']) ? $_SESSION['login_time'] : $current_time;
    
    if ($current_time - $login_time > SESSION_TIMEOUT) {
        session_destroy();
        header("Location: " . APP_URL . "/login.php?session=expired");
        exit();
    }
    
    $_SESSION['login_time'] = $current_time;
}

function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

function userRole() {
    return isset($_SESSION['user_role']) ? $_SESSION['user_role'] : null;
}

function getCurrentUserId() {
    return isset($_SESSION['user_id']) ? $_SESSION['user_id'] : null;
}
?>