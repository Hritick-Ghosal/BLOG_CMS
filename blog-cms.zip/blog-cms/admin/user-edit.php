<?php
include '../config/db.php';
include '../config/constants.php';
include '../config/session.php';

if (!isLoggedIn() || userRole() !== ADMIN_ROLE) {
    header("Location: " . APP_URL . "/login.php");
    exit();
}

$user_id = $_GET['id'] ?? 0;
$error = '';
$success = '';

$stmt = $conn->prepare("SELECT id, username, email, full_name, status FROM users WHERE id = ? AND role = 'author'");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    die("User not found.");
}

$user = $result->fetch_assoc();
$stmt->close();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $full_name = trim($_POST['full_name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $status = $_POST['status'] ?? 'active';
    
    if (empty($full_name) || empty($email)) {
        $error = "All fields are required.";
    } else {
        $check_stmt = $conn->prepare("SELECT id FROM users WHERE email = ? AND id != ?");
        $check_stmt->bind_param("si", $email, $user_id);
        $check_stmt->execute();
        $check_result = $check_stmt->get_result();
        
        if ($check_result->num_rows > 0) {
            $error = "Email already exists.";
        } else {
            $update_stmt = $conn->prepare("UPDATE users SET full_name = ?, email = ?, status = ? WHERE id = ?");
            $update_stmt->bind_param("sssi", $full_name, $email, $status, $user_id);
            
            if ($update_stmt->execute()) {
                $success = "User updated successfully!";
                $user['full_name'] = $full_name;
                $user['email'] = $email;
                $user['status'] = $status;
            } else {
                $error = "Failed to update user.";
            }
            $update_stmt->close();
        }
        $check_stmt->close();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit User - <?php echo APP_NAME; ?></title>
    <link rel="stylesheet" href="../assets/css/styles.css">
    <link rel="stylesheet" href="../assets/css/styles.css">
</head>
<body>
    <div class="navbar">
        <h1><?php echo APP_NAME; ?> - Edit User</h1>
        <div class="navbar-menu">
            <a href="users.php">Back</a>
            <a href="logout.php">Logout</a>
        </div>
    </div>
    
    <div class="admin-container">
        <div class="form-card">
            <h1>Edit User</h1>
            
            <?php if (!empty($error)): ?>
                <div class="error"><?php echo htmlspecialchars($error); ?></div>
            <?php endif; ?>
            
            <?php if (!empty($success)): ?>
                <div class="success"><?php echo htmlspecialchars($success); ?></div>
            <?php endif; ?>
            
            <form method="POST">
                <div class="form-group">
                    <label for="full_name">Full Name</label>
                    <input type="text" id="full_name" name="full_name" value="<?php echo htmlspecialchars($user['full_name']); ?>" required>
                </div>
                
                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($user['email']); ?>" required>
                </div>
                
                <div class="form-group">
                    <label for="status">Status</label>
                    <select id="status" name="status" required>
                        <option value="active" <?php echo $user['status'] === 'active' ? 'selected' : ''; ?>>Active</option>
                        <option value="inactive" <?php echo $user['status'] === 'inactive' ? 'selected' : ''; ?>>Inactive</option>
                        <option value="blocked" <?php echo $user['status'] === 'blocked' ? 'selected' : ''; ?>>Blocked</option>
                    </select>
                </div>
                
                <div class="button-group">
                    <button type="submit" class="btn btn-primary">Save Changes</button>
                    <a href="users.php" class="btn btn-secondary">Cancel</a>
                </div>
            </form>
        </div>
    </div>
</body>
</html>
