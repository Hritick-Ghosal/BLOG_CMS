<?php
include '../config/db.php';
include '../config/constants.php';
include '../config/session.php';

if (!isLoggedIn() || userRole() !== ADMIN_ROLE) {
    header("Location: " . APP_URL . "/login.php");
    exit();
}

$query = "SELECT id, username, email, full_name, status, created_at, last_login FROM users WHERE role = 'author' ORDER BY created_at DESC";
$result = $conn->query($query);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Authors - <?php echo APP_NAME; ?></title>
    <link rel="stylesheet" href="../assets/css/styles.css">
    <link rel="stylesheet" href="../assets/css/styles.css">
</head>.
<body>
    <div class="navbar">
        <h1><?php echo APP_NAME; ?> - Manage Authors</h1>
        <div class="navbar-menu">
            <a href="dashboard.php">Dashboard</a>
            <a href="logout.php">Logout</a>
        </div>
    </div>
    
    <div class="admin-container">
        <div class="page-header">
            <h1>All Authors</h1>
            <a href="dashboard.php" class="btn btn-primary">← Back to Dashboard</a>
        </div>
        
        <?php if ($result->num_rows > 0): ?>
            <div class="data-table-container">
                <table>
                    <thead>
                        <tr>
                            <th>Username</th>
                            <th>Email</th>
                            <th>Full Name</th>
                            <th>Status</th>
                            <th>Joined</th>
                            <th>Last Login</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($user = $result->fetch_assoc()): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($user['username']); ?></td>
                                <td><?php echo htmlspecialchars($user['email']); ?></td>
                                <td><?php echo htmlspecialchars($user['full_name']); ?></td>
                                <td><span class="status <?php echo $user['status']; ?>"><?php echo ucfirst($user['status']); ?></span></td>
                                <td><?php echo date('M d, Y', strtotime($user['created_at'])); ?></td>
                                <td><?php echo $user['last_login'] ? date('M d, Y H:i', strtotime($user['last_login'])) : 'Never'; ?></td>
                                <td>
                                    <div class="action-btns">
                                        <a href="user-details.php?id=<?php echo $user['id']; ?>" class="btn btn-primary">View</a>
                                        <a href="user-edit.php?id=<?php echo $user['id']; ?>" class="btn btn-warning">Edit</a>
                                        <a href="user-delete.php?id=<?php echo $user['id']; ?>" class="btn btn-danger" onclick="return confirm('Delete this user and all their posts?')">Delete</a>
                                    </div>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <div class="card">
                <div class="no-data">
                    <p>No authors found.</p>
                </div>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>
