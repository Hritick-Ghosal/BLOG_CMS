<?php
include '../config/db.php';
include '../config/constants.php';
include '../config/session.php';

if (!isLoggedIn() || userRole() !== ADMIN_ROLE) {
    header("Location: " . APP_URL . "/login.php");
    exit();
}

$user_id = $_GET['id'] ?? 0;
$stmt = $conn->prepare("SELECT id, username, email, full_name, status, created_at, last_login FROM users WHERE id = ? AND role = 'author'");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    die("User not found.");
}

$user = $result->fetch_assoc();

$posts_query = $conn->prepare("SELECT id, title, status, created_at, views FROM posts WHERE author_id = ? ORDER BY created_at DESC");
$posts_query->bind_param("i", $user_id);
$posts_query->execute();
$posts_result = $posts_query->get_result();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Details - <?php echo APP_NAME; ?></title>
    <link rel="stylesheet" href="../assets/css/styles.css">
    <link rel="stylesheet" href="../assets/css/styles.css">
</head>
<body>
    <div class="navbar">
        <h1><?php echo APP_NAME; ?> - User Details</h1>
        <div class="navbar-menu">
            <a href="users.php">Back to Authors</a>
            <a href="logout.php">Logout</a>
        </div>
    </div>
    
    <div class="admin-container">
        <div class="user-card">
            <h1><?php echo htmlspecialchars($user['full_name']); ?></h1>
            
            <div class="user-info">
                <div class="info-item">
                    <div class="info-label">Username</div>
                    <div class="info-value"><?php echo htmlspecialchars($user['username']); ?></div>
                </div>
                <div class="info-item">
                    <div class="info-label">Email</div>
                    <div class="info-value"><?php echo htmlspecialchars($user['email']); ?></div>
                </div>
                <div class="info-item">
                    <div class="info-label">Status</div>
                    <div class="info-value">
                        <span class="status <?php echo $user['status']; ?>"><?php echo ucfirst($user['status']); ?></span>
                    </div>
                </div>
                <div class="info-item">
                    <div class="info-label">Member Since</div>
                    <div class="info-value"><?php echo date('M d, Y', strtotime($user['created_at'])); ?></div>
                </div>
                <div class="info-item">
                    <div class="info-label">Last Login</div>
                    <div class="info-value"><?php echo $user['last_login'] ? date('M d, Y H:i', strtotime($user['last_login'])) : 'Never'; ?></div>
                </div>
            </div>
            
            <div style="margin-top: 20px;">
                <a href="user-edit.php?id=<?php echo $user['id']; ?>" class="btn btn-primary">Edit User</a>
                <a href="user-delete.php?id=<?php echo $user['id']; ?>" class="btn btn-danger" onclick="return confirm('Delete this user?')">Delete User</a>
            </div>
        </div>
        
        <div class="posts-section">
            <h2>User's Posts</h2>
            
            <?php if ($posts_result->num_rows > 0): ?>
                <div class="data-table-container">
                    <table>
                        <thead>
                            <tr>
                                <th>Title</th>
                                <th>Status</th>
                                <th>Views</th>
                                <th>Created</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($post = $posts_result->fetch_assoc()): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($post['title']); ?></td>
                                    <td><span class="status <?php echo $post['status']; ?>"><?php echo ucfirst($post['status']); ?></span></td>
                                    <td><?php echo $post['views']; ?></td>
                                    <td><?php echo date('M d, Y', strtotime($post['created_at'])); ?></td>
                                </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <div class="no-data">
                    <p>No posts found for this user.</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>
