<?php
include '../config/db.php';
include '../config/constants.php';
include '../config/session.php';

if (!isLoggedIn() || userRole() !== ADMIN_ROLE) {
    header("Location: " . APP_URL . "/login.php");
    exit();
}

$stats = [];

// Count total authors
$users_result = $conn->query("SELECT COUNT(*) as count FROM users WHERE role = 'author'");
$stats['total_users'] = $users_result->fetch_assoc()['count'];

// Count published posts
$posts_result = $conn->query("SELECT COUNT(*) as count FROM posts WHERE status = 'published'");
$stats['total_posts'] = $posts_result->fetch_assoc()['count'];

// Count total views
$views_result = $conn->query("SELECT SUM(views) as total FROM posts");
$stats['total_views'] = $views_result->fetch_assoc()['total'] ?? 0;

// Count pending comments
$comments_result = $conn->query("SELECT COUNT(*) as count FROM post_comments WHERE status = 'pending'");
$stats['pending_comments'] = $comments_result->fetch_assoc()['count'];

// Get recent users
$recent_users = $conn->query("SELECT id, username, email, created_at FROM users WHERE role = 'author' ORDER BY created_at DESC LIMIT 5");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - <?php echo APP_NAME; ?></title>
    <link rel="stylesheet" href="../assets/css/styles.css">
</head>
<body>
    <div class="navbar">
        <h1><?php echo APP_NAME; ?> - Admin Panel</h1>
        <div class="navbar-menu">
            <span>👤 <?php echo htmlspecialchars($_SESSION['username']); ?></span>
            <a href="logout.php">Logout</a>
        </div>
    </div>
    
    <div class="admin-container">
        <!-- Welcome Section -->
        <div class="welcome-section">
            <h2>Welcome to Admin Dashboard</h2>
            <p>Manage all users, posts, comments and content from this centralized control panel.</p>
        </div>
        
        <!-- Statistics -->
        <div class="stats-grid">
            <div class="stat-card">
                <h3>Total Authors</h3>
                <div class="value"><?php echo $stats['total_users']; ?></div>
            </div>
            <div class="stat-card">
                <h3>Published Posts</h3>
                <div class="value"><?php echo $stats['total_posts']; ?></div>
            </div>
            <div class="stat-card">
                <h3>Total Views</h3>
                <div class="value"><?php echo number_format($stats['total_views']); ?></div>
            </div>
            <div class="stat-card">
                <h3>Pending Comments</h3>
                <div class="value" style="color: #ffa500;"><?php echo $stats['pending_comments']; ?></div>
            </div>
        </div>
        
        <!-- Quick Links -->
        <div class="quick-links">
            <a href="users.php" class="quick-link">👥 Manage Authors</a>
            <a href="comments.php" class="quick-link">💬 Manage Comments <?php if ($stats['pending_comments'] > 0): ?><span style="background: #ff4757; padding: 2px 8px; border-radius: 12px; font-size: 11px; margin-left: 8px;"><?php echo $stats['pending_comments']; ?></span><?php endif; ?></a>
            <a href="../public/index.php" class="quick-link">👁 View Public Site</a>
        </div>
        
        <!-- Recent Authors -->
        <div class="posts-section">
            <h3>Recent Authors</h3>
            <div class="data-table-container">
                <table>
                    <thead>
                        <tr>
                            <th>Username</th>
                            <th>Email</th>
                            <th>Joined</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($user = $recent_users->fetch_assoc()): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($user['username']); ?></td>
                                <td><?php echo htmlspecialchars($user['email']); ?></td>
                                <td><?php echo date('M d, Y', strtotime($user['created_at'])); ?></td>
                                <td>
                                    <div class="action-btns">
                                        <a href="user-details.php?id=<?php echo $user['id']; ?>" class="btn btn-primary">View</a>
                                        <a href="user-edit.php?id=<?php echo $user['id']; ?>" class="btn btn-warning">Edit</a>
                                    </div>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</body>
</html>
