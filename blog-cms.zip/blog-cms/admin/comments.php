<?php
include '../config/db.php';
include '../config/constants.php';
include '../config/session.php';

// Check if user is admin
if (!isLoggedIn() || userRole() !== ADMIN_ROLE) {
    header("Location: " . APP_URL . "/login.php");
    exit();
}

$action = $_GET['action'] ?? '';
$comment_id = intval($_GET['id'] ?? 0);

// Handle approval
if ($action === 'approve' && !empty($comment_id)) {
    $update = $conn->prepare("UPDATE post_comments SET status = 'approved' WHERE id = ?");
    $update->bind_param("i", $comment_id);
    if ($update->execute()) {
        header("Location: comments.php?success=approved");
        exit();
    }
    $update->close();
}

// Handle rejection
if ($action === 'reject' && !empty($comment_id)) {
    $update = $conn->prepare("UPDATE post_comments SET status = 'rejected' WHERE id = ?");
    $update->bind_param("i", $comment_id);
    if ($update->execute()) {
        header("Location: comments.php?success=rejected");
        exit();
    }
    $update->close();
}

// Handle deletion
if ($action === 'delete' && !empty($comment_id)) {
    $delete = $conn->prepare("DELETE FROM post_comments WHERE id = ?");
    $delete->bind_param("i", $comment_id);
    if ($delete->execute()) {
        header("Location: comments.php?success=deleted");
        exit();
    }
    $delete->close();
}

// Get all comments with post info
$all_comments = $conn->query("
    SELECT c.id, c.author_name, c.author_email, c.content, c.status, c.created_at, p.title, p.slug
    FROM post_comments c
    JOIN posts p ON c.post_id = p.id
    ORDER BY c.created_at DESC
");

// Get comment statistics
$stats_query = $conn->query("
    SELECT 
        COUNT(*) as total,
        SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending,
        SUM(CASE WHEN status = 'approved' THEN 1 ELSE 0 END) as approved,
        SUM(CASE WHEN status = 'rejected' THEN 1 ELSE 0 END) as rejected
    FROM post_comments
");
$stats = $stats_query->fetch_assoc();

// Get filter if applied
$filter = $_GET['filter'] ?? 'all';
$filter_valid = in_array($filter, ['all', 'pending', 'approved', 'rejected']);
$filter = $filter_valid ? $filter : 'all';

// Get filtered comments
if ($filter === 'all') {
    $comments = $conn->query("
        SELECT c.id, c.author_name, c.author_email, c.content, c.status, c.created_at, p.title, p.slug
        FROM post_comments c
        JOIN posts p ON c.post_id = p.id
        ORDER BY c.created_at DESC
    ");
} else {
    $comments = $conn->prepare("
        SELECT c.id, c.author_name, c.author_email, c.content, c.status, c.created_at, p.title, p.slug
        FROM post_comments c
        JOIN posts p ON c.post_id = p.id
        WHERE c.status = ?
        ORDER BY c.created_at DESC
    ");
    $comments->bind_param("s", $filter);
    $comments->execute();
    $comments = $comments->get_result();
}

$success_msg = '';
if (isset($_GET['success'])) {
    $success_type = $_GET['success'];
    if ($success_type === 'approved') $success_msg = 'Comment approved successfully!';
    if ($success_type === 'rejected') $success_msg = 'Comment rejected successfully!';
    if ($success_type === 'deleted') $success_msg = 'Comment deleted successfully!';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Comments - <?php echo APP_NAME; ?></title>
    <link rel="stylesheet" href="../assets/css/styles.css">
</head>
<body>
    <!-- Navbar -->
    <div class="navbar">
        <h1><?php echo APP_NAME; ?> - Comments Management</h1>
        <div class="navbar-menu">
            <span>👤 <?php echo htmlspecialchars($_SESSION['username']); ?></span>
            <a href="dashboard.php">Dashboard</a>
            <a href="logout.php">Logout</a>
        </div>
    </div>
    
    <div class="admin-container">
        <!-- Page Header -->
        <div class="page-header">
            <h1>💬 Manage Comments</h1>
            <a href="dashboard.php" class="btn btn-primary">← Back to Dashboard</a>
        </div>
        
        <!-- Success Message -->
        <?php if (!empty($success_msg)): ?>
            <div class="success"><?php echo $success_msg; ?></div>
        <?php endif; ?>
        
        <!-- Statistics -->
        <?php if ($stats['total'] > 0): ?>
            <div class="stats-grid" style="margin-bottom: 32px;">
                <div class="stat-card">
                    <h3>Total Comments</h3>
                    <div class="value"><?php echo intval($stats['total']); ?></div>
                </div>
                <div class="stat-card">
                    <h3>Pending Approval</h3>
                    <div class="value" style="color: #ffa500;"><?php echo intval($stats['pending'] ?? 0); ?></div>
                </div>
                <div class="stat-card">
                    <h3>Approved</h3>
                    <div class="value" style="color: #00ff88;"><?php echo intval($stats['approved'] ?? 0); ?></div>
                </div>
                <div class="stat-card">
                    <h3>Rejected</h3>
                    <div class="value" style="color: #ff4757;"><?php echo intval($stats['rejected'] ?? 0); ?></div>
                </div>
            </div>
        <?php endif; ?>
        
        <!-- Filter Buttons -->
        <div style="display: flex; gap: 12px; margin-bottom: 24px; flex-wrap: wrap;">
            <a href="?filter=all" class="btn <?php echo $filter === 'all' ? 'btn-primary' : 'btn-secondary'; ?>" style="padding: 10px 16px; font-size: 13px;">All Comments</a>
            <a href="?filter=pending" class="btn <?php echo $filter === 'pending' ? 'btn-primary' : 'btn-secondary'; ?>" style="padding: 10px 16px; font-size: 13px;">⏳ Pending (<?php echo intval($stats['pending'] ?? 0); ?>)</a>
            <a href="?filter=approved" class="btn <?php echo $filter === 'approved' ? 'btn-primary' : 'btn-secondary'; ?>" style="padding: 10px 16px; font-size: 13px;">✓ Approved (<?php echo intval($stats['approved'] ?? 0); ?>)</a>
            <a href="?filter=rejected" class="btn <?php echo $filter === 'rejected' ? 'btn-primary' : 'btn-secondary'; ?>" style="padding: 10px 16px; font-size: 13px;">✕ Rejected (<?php echo intval($stats['rejected'] ?? 0); ?>)</a>
        </div>
        
        <!-- Comments List -->
        <?php if ($comments->num_rows > 0): ?>
            <div>
                <?php while ($comment = $comments->fetch_assoc()): ?>
                    <div class="comment-item-admin">
                        <!-- Header with Author Info -->
                        <div class="comment-header">
                            <div style="flex: 1;">
                                <div style="display: flex; align-items: center; gap: 12px; margin-bottom: 8px;">
                                    <strong class="comment-author"><?php echo htmlspecialchars($comment['author_name']); ?></strong>
                                    <span class="status status-<?php echo $comment['status']; ?>"><?php echo strtoupper($comment['status']); ?></span>
                                </div>
                                <div style="font-size: 12px; color: #b0b3b8; margin-bottom: 4px;">
                                    📧 <a href="mailto:<?php echo htmlspecialchars($comment['author_email']); ?>" style="color: #00d4ff; text-decoration: none;">
                                        <?php echo htmlspecialchars($comment['author_email']); ?>
                                    </a>
                                </div>
                                <div style="font-size: 12px; color: #b0b3b8; margin-bottom: 4px;">
                                    📄 On Post: <a href="../public/post.php?slug=<?php echo urlencode($comment['slug']); ?>" style="color: #00d4ff; text-decoration: none;" target="_blank">
                                        "<?php echo htmlspecialchars(substr($comment['title'], 0, 60)); ?><?php echo strlen($comment['title']) > 60 ? '...' : ''; ?>"
                                    </a>
                                </div>
                                <div style="font-size: 12px; color: #616569;">
                                    🕐 <?php echo date('M d, Y H:i', strtotime($comment['created_at'])); ?>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Comment Content -->
                        <div style="background: #0f1419; padding: 16px; border-radius: 6px; margin: 16px 0; border-left: 4px solid #00d4ff;">
                            <p style="color: #b0b3b8; line-height: 1.6; margin: 0;">
                                <?php echo nl2br(htmlspecialchars($comment['content'])); ?>
                            </p>
                        </div>
                        
                        <!-- Action Buttons -->
                        <div class="comment-actions">
                            <?php if ($comment['status'] !== 'approved'): ?>
                                <a href="?action=approve&id=<?php echo $comment['id']; ?>" class="action-btn approve-btn" title="Approve this comment">
                                    ✓ Approve
                                </a>
                            <?php else: ?>
                                <button class="action-btn approve-btn" disabled style="opacity: 0.5; cursor: not-allowed;">
                                    ✓ Approved
                                </button>
                            <?php endif; ?>
                            
                            <?php if ($comment['status'] !== 'rejected'): ?>
                                <a href="?action=reject&id=<?php echo $comment['id']; ?>" class="action-btn reject-btn" title="Reject this comment" onclick="return confirm('Are you sure you want to reject this comment?');">
                                    ✕ Reject
                                </a>
                            <?php else: ?>
                                <button class="action-btn reject-btn" disabled style="opacity: 0.5; cursor: not-allowed;">
                                    ✕ Rejected
                                </button>
                            <?php endif; ?>
                            
                            <a href="?action=delete&id=<?php echo $comment['id']; ?>" class="action-btn delete-btn" title="Delete this comment" onclick="return confirm('Permanently delete this comment? This cannot be undone.');">
                                🗑 Delete
                            </a>
                        </div>
                    </div>
                <?php endwhile; ?>
            </div>
        <?php else: ?>
            <div class="card">
                <div class="no-data">
                    <p>
                        <?php if ($filter === 'pending'): ?>
                            ✓ No pending comments! All comments have been reviewed.
                        <?php elseif ($filter === 'approved'): ?>
                            No approved comments yet.
                        <?php elseif ($filter === 'rejected'): ?>
                            No rejected comments.
                        <?php else: ?>
                            No comments yet.
                        <?php endif; ?>
                    </p>
                </div>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>
