<?php
include '../config/db.php';
include '../config/constants.php';
include '../config/session.php';

if (!isLoggedIn() || userRole() !== ADMIN_ROLE) {
    header("Location: " . APP_URL . "/login.php");
    exit();
}

$user_id = $_GET['id'] ?? 0;

$stmt = $conn->prepare("DELETE FROM users WHERE id = ? AND role = 'author'");
$stmt->bind_param("i", $user_id);

if ($stmt->execute()) {
    header("Location: users.php?deleted=1");
} else {
    header("Location: users.php?error=1");
}

$stmt->close();
?>
