<?php
include '../config/db.php';
include '../config/constants.php';
include '../config/session.php';

if (!isLoggedIn() || userRole() !== AUTHOR_ROLE) {
    header("Location: " . APP_URL . "/login.php");
    exit();
}

$author_id = getCurrentUserId();
$post_id = $_GET['id'] ?? 0;

$stmt = $conn->prepare("DELETE FROM posts WHERE id = ? AND author_id = ?");
$stmt->bind_param("ii", $post_id, $author_id);

if ($stmt->execute()) {
    header("Location: posts.php?deleted=1");
} else {
    header("Location: posts.php?error=1");
}

$stmt->close();
?>
