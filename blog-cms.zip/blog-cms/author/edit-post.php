<?php
include '../config/db.php';
include '../config/constants.php';
include '../config/session.php';
include '../config/upload.php';

if (!isLoggedIn() || userRole() !== AUTHOR_ROLE) {
    header("Location: " . APP_URL . "/login.php");
    exit();
}

$author_id = getCurrentUserId();
$post_id = $_GET['id'] ?? 0;
$error = '';
$success = '';
$uploader = new ImageUploader();

$stmt = $conn->prepare("SELECT id, title, content, excerpt, status, featured_image FROM posts WHERE id = ? AND author_id = ?");
$stmt->bind_param("ii", $post_id, $author_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    die("Post not found or you don't have permission to edit it.");
}

$post = $result->fetch_assoc();
$stmt->close();

if (isset($_GET['created'])) {
    $success = "Post created successfully!";
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim($_POST['title'] ?? '');
    $content = trim($_POST['content'] ?? '');
    $excerpt = trim($_POST['excerpt'] ?? '');
    $status = $_POST['status'] ?? 'draft';
    $featured_image = $post['featured_image'];
    
    if (empty($title) || empty($content)) {
        $error = "Title and content are required.";
    } else {
        // Handle image upload/update
        if (isset($_FILES['featured_image']) && $_FILES['featured_image']['size'] > 0) {
            $upload_result = $uploader->upload($_FILES['featured_image']);
            if ($upload_result['success']) {
                // Delete old image if exists
                if (!empty($post['featured_image'])) {
                    $uploader->delete($post['featured_image']);
                }
                $featured_image = $upload_result['filename'];
            } else {
                $error = $upload_result['error'];
            }
        }
        
        // Check if image should be deleted
        if (isset($_POST['delete_image']) && $_POST['delete_image'] === 'yes') {
            if (!empty($post['featured_image'])) {
                $uploader->delete($post['featured_image']);
                $featured_image = '';
            }
        }
        
        if (empty($error)) {
            $update_stmt = $conn->prepare("
                UPDATE posts 
                SET title = ?, content = ?, excerpt = ?, status = ?, featured_image = ?, published_at = ?
                WHERE id = ? AND author_id = ?
            ");
            
            $published_at = ($status === 'published') ? date('Y-m-d H:i:s') : NULL;
            $update_stmt->bind_param("ssssssii", $title, $content, $excerpt, $status, $featured_image, $published_at, $post_id, $author_id);
            
            if ($update_stmt->execute()) {
                $success = "Post updated successfully!";
                $post['title'] = $title;
                $post['content'] = $content;
                $post['excerpt'] = $excerpt;
                $post['status'] = $status;
                $post['featured_image'] = $featured_image;
            } else {
                $error = "Failed to update post.";
            }
            $update_stmt->close();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Post - <?php echo APP_NAME; ?></title>
    <link rel="stylesheet" href="../assets/css/styles.css">
    <link rel="stylesheet" href="../assets/css/styles.css">
    <style>
        .image-preview {
            max-width: 300px;
            margin-top: 15px;
            border-radius: 5px;
            border: 1px solid #ddd;
            padding: 10px;
        }
        .image-preview img {
            max-width: 100%;
            height: auto;
            border-radius: 3px;
        }
        .delete-image-btn {
            background: #e74c3c;
            color: white;
            padding: 8px 15px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            margin-top: 10px;
            font-size: 14px;
        }
        .delete-image-btn:hover {
            background: #c0392b;
        }
    </style>
</head>
<body>
    <div class="navbar">
        <h1><?php echo APP_NAME; ?> - Edit Post</h1>
        <div class="navbar-menu">
            <a href="dashboard.php">Dashboard</a>
            <a href="posts.php">All Posts</a>
            <a href="logout.php">Logout</a>
        </div>
    </div>
    
    <div class="author-container">
        <div class="post-editor">
            <h1>Edit Post</h1>
            
            <?php if (!empty($error)): ?>
                <div class="error"><?php echo htmlspecialchars($error); ?></div>
            <?php endif; ?>
            
            <?php if (!empty($success)): ?>
                <div class="success"><?php echo htmlspecialchars($success); ?></div>
            <?php endif; ?>
            
            <form method="POST" enctype="multipart/form-data">
                <div class="form-group">
                    <label for="title">Post Title</label>
                    <input type="text" id="title" name="title" value="<?php echo htmlspecialchars($post['title']); ?>" required>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="excerpt">Excerpt</label>
                        <input type="text" id="excerpt" name="excerpt" value="<?php echo htmlspecialchars($post['excerpt']); ?>" placeholder="Short summary of your post">
                    </div>
                    
                    <div class="form-group">
                        <label for="status">Status</label>
                        <select id="status" name="status" required>
                            <option value="draft" <?php echo $post['status'] === 'draft' ? 'selected' : ''; ?>>Draft</option>
                            <option value="published" <?php echo $post['status'] === 'published' ? 'selected' : ''; ?>>Published</option>
                        </select>
                    </div>
                </div>
                
                <!-- Featured Image Section -->
                <div class="form-group">
                    <label for="featured_image">Featured Image</label>
                    <input type="file" id="featured_image" name="featured_image" accept="image/jpeg,image/png,image/gif,image/webp">
                    <small style="color: #666;">Accepted formats: JPG, PNG, GIF, WebP (Max 5MB)</small>
                    
                    <!-- Display current image -->
                    <?php if (!empty($post['featured_image'])): ?>
                        <div class="image-preview">
                            <h4>Current Image:</h4>
                            <img src="<?php echo htmlspecialchars($uploader->getUploadUrl($post['featured_image'])); ?>" alt="Post image">
                            <br>
                            <label style="margin-top: 10px;">
                                <input type="checkbox" name="delete_image" value="yes"> Delete this image
                            </label>
                        </div>
                    <?php endif; ?>
                </div>
                
                <div class="form-group">
                    <label for="content">Post Content</label>
                    <textarea id="content" name="content" required><?php echo htmlspecialchars($post['content']); ?></textarea>
                </div>
                
                <div class="button-group">
                    <button type="submit" class="btn btn-success">Save Changes</button>
                    <a href="posts.php" class="btn btn-secondary">Cancel</a>
                </div>
            </form>
        </div>
    </div>
</body>
</html>
