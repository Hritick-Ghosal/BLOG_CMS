<?php
include '../config/db.php';
include '../config/constants.php';
include '../config/session.php';
include '../config/upload.php';

if (!isLoggedIn() || userRole() !== AUTHOR_ROLE) {
    header("Location: " . APP_URL . "/login.php");
    exit();
}

$author_id = getCurrentUserId();
$error = '';
$success = '';
$uploader = new ImageUploader();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim($_POST['title'] ?? '');
    $content = trim($_POST['content'] ?? '');
    $excerpt = trim($_POST['excerpt'] ?? '');
    $status = $_POST['status'] ?? 'draft';
    $featured_image = '';
    
    if (empty($title) || empty($content)) {
        $error = "Title and content are required.";
    } else {
        // Handle image upload
        if (isset($_FILES['featured_image']) && $_FILES['featured_image']['size'] > 0) {
            $upload_result = $uploader->upload($_FILES['featured_image']);
            if ($upload_result['success']) {
                $featured_image = $upload_result['filename'];
            } else {
                $error = $upload_result['error'];
            }
        }
        
        if (empty($error)) {
            // Generate slug from title
            $slug = strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '-', $title)));
            
            // Check if slug is unique
            $check_stmt = $conn->prepare("SELECT id FROM posts WHERE slug = ?");
            $check_stmt->bind_param("s", $slug);
            $check_stmt->execute();
            $check_result = $check_stmt->get_result();
            
            if ($check_result->num_rows > 0) {
                $slug = $slug . '-' . time();
            }
            $check_stmt->close();
            
            $insert_stmt = $conn->prepare("
                INSERT INTO posts (author_id, title, slug, content, excerpt, featured_image, status, published_at) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ");
            
            $published_at = ($status === 'published') ? date('Y-m-d H:i:s') : NULL;
            
            // Bind published_at separately
            $insert_stmt->bind_param("isssssis", $author_id, $title, $slug, $content, $excerpt, $featured_image, $status, $published_at);
            
            if ($insert_stmt->execute()) {
                $post_id = $conn->insert_id;
                header("Location: edit-post.php?id=$post_id&created=1");
                exit();
            } else {
                $error = "Failed to create post.";
            }
            $insert_stmt->close();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Post - <?php echo APP_NAME; ?></title>
    <link rel="stylesheet" href="../assets/css/styles.css">
    <link rel="stylesheet" href="../assets/css/styles.css">
</head>
<body>
    <div class="navbar">
        <h1><?php echo APP_NAME; ?> - Create Post</h1>
        <div class="navbar-menu">
            <a href="dashboard.php">Dashboard</a>
            <a href="logout.php">Logout</a>
        </div>
    </div>
    
    <div class="author-container">
        <div class="post-editor">
            <h1>Create New Post</h1>
            
            <?php if (!empty($error)): ?>
                <div class="error"><?php echo htmlspecialchars($error); ?></div>
            <?php endif; ?>
            
            <form method="POST" enctype="multipart/form-data">
                <div class="form-group">
                    <label for="title">Post Title</label>
                    <input type="text" id="title" name="title" placeholder="Enter an engaging title for your post..." required>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="excerpt">Excerpt (Short Summary)</label>
                        <input type="text" id="excerpt" name="excerpt" placeholder="Brief description of your post...">
                    </div>
                    
                    <div class="form-group">
                        <label for="status">Status</label>
                        <select id="status" name="status" required>
                            <option value="draft">Draft</option>
                            <option value="published">Published</option>
                        </select>
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="featured_image">Featured Image</label>
                    <input type="file" id="featured_image" name="featured_image" accept="image/jpeg,image/png,image/gif,image/webp">
                    <small style="color: #666;">Accepted formats: JPG, PNG, GIF, WebP (Max 5MB)</small>
                </div>
                
                <div class="form-group">
                    <label for="content">Post Content</label>
                    <textarea id="content" name="content" required placeholder="Write your post content here..."></textarea>
                </div>
                
                <div class="button-group">
                    <button type="submit" class="btn btn-success">Create Post</button>
                    <a href="dashboard.php" class="btn btn-secondary">Cancel</a>
                </div>
            </form>
        </div>
    </div>
</body>
</html>
