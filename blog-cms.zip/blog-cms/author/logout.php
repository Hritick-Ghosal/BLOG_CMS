<?php
include '../config/db.php';
include '../config/constants.php';
include '../config/session.php';

if (isLoggedIn()) {
    $user_id = $_SESSION['user_id'];
    $ip_address = $_SERVER['REMOTE_ADDR'];
    $log_stmt = $conn->prepare("INSERT INTO activity_logs (user_id, action, ip_address) VALUES (?, 'logout', ?)");
    $log_stmt->bind_param("is", $user_id, $ip_address);
    $log_stmt->execute();
    $log_stmt->close();
}

session_destroy();
header("Location: " . APP_URL . "/login.php?logout=1");
exit();
?>
