<?php
include '../config/db.php';
include '../config/constants.php';
include '../config/session.php';

if (!isLoggedIn() || userRole() !== AUTHOR_ROLE) {
    header("Location: " . APP_URL . "/login.php");
    exit();
}

$author_id = getCurrentUserId();

$query = $conn->prepare("
    SELECT id, title, status, views, created_at 
    FROM posts 
    WHERE author_id = ? 
    ORDER BY created_at DESC 
    LIMIT 10
");
$query->bind_param("i", $author_id);
$query->execute();
$posts_result = $query->get_result();

$stats_query = $conn->prepare("
    SELECT 
        COUNT(*) as total_posts,
        SUM(CASE WHEN status = 'published' THEN 1 ELSE 0 END) as published_posts,
        SUM(CASE WHEN status = 'draft' THEN 1 ELSE 0 END) as draft_posts,
        SUM(views) as total_views
    FROM posts 
    WHERE author_id = ?
");
$stats_query->bind_param("i", $author_id);
$stats_query->execute();
$stats_result = $stats_query->get_result();
$stats = $stats_result->fetch_assoc();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Author Dashboard - <?php echo APP_NAME; ?></title>
    <link rel="stylesheet" href="../assets/css/styles.css">
    <link rel="stylesheet" href="../assets/css/styles.css">
</head>
<body>
    <div class="navbar">
        <h1><?php echo APP_NAME; ?> - Author Panel</h1>
        <div class="navbar-menu">
            <span>Welcome, <?php echo htmlspecialchars($_SESSION['username']); ?></span>
            <a href="change-password.php">Change Password</a>
            <a href="logout.php">Logout</a>
        </div>
    </div>
    
    <div class="author-container">
        <div class="welcome-section">
            <h2>Welcome to Your Dashboard</h2>
            <p>Create, edit, and manage your blog posts from here.</p>
        </div>
        
        <div class="stats-grid">
            <div class="stat-card">
                <h3>Total Posts</h3>
                <div class="value"><?php echo $stats['total_posts'] ?? 0; ?></div>
            </div>
            <div class="stat-card">
                <h3>Published</h3>
                <div class="value"><?php echo $stats['published_posts'] ?? 0; ?></div>
            </div>
            <div class="stat-card">
                <h3>Drafts</h3>
                <div class="value"><?php echo $stats['draft_posts'] ?? 0; ?></div>
            </div>
            <div class="stat-card">
                <h3>Total Views</h3>
                <div class="value"><?php echo number_format($stats['total_views'] ?? 0); ?></div>
            </div>
        </div>
        
        <div class="quick-links">
            <a href="create-post.php" class="quick-link">+ Create New Post</a>
            <a href="posts.php" class="quick-link">View All Posts</a>
            <a href="../public/index.php" class="quick-link">View Public Site</a>
        </div>
        
        <div class="posts-section">
            <h3>Recent Posts</h3>
            
            <?php if ($posts_result->num_rows > 0): ?>
                <div class="data-table-container">
                    <table>
                        <thead>
                            <tr>
                                <th>Title</th>
                                <th>Status</th>
                                <th>Views</th>
                                <th>Created</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($post = $posts_result->fetch_assoc()): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($post['title']); ?></td>
                                    <td><span class="status <?php echo $post['status']; ?>"><?php echo ucfirst($post['status']); ?></span></td>
                                    <td><?php echo $post['views']; ?></td>
                                    <td><?php echo date('M d, Y', strtotime($post['created_at'])); ?></td>
                                    <td>
                                        <div class="action-btns">
                                            <a href="edit-post.php?id=<?php echo $post['id']; ?>" class="btn btn-primary">Edit</a>
                                            <a href="delete-post.php?id=<?php echo $post['id']; ?>" class="btn btn-danger" onclick="return confirm('Delete this post?')">Delete</a>
                                        </div>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <div class="no-data">
                    <p>No posts yet. <a href="create-post.php">Create your first post</a></p>
                </div>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>
