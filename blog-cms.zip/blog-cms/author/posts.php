<?php
include '../config/db.php';
include '../config/constants.php';

$slug = $_GET['slug'] ?? '';

$stmt = $conn->prepare("
    SELECT p.id, p.title, p.content, p.featured_image, p.views, p.published_at, p.likes, p.dislikes, u.username, u.id as author_id
    FROM posts p 
    JOIN users u ON p.author_id = u.id 
    WHERE p.slug = ? AND p.status = 'published'
");
$stmt->bind_param("s", $slug);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    die("Post not found.");
}

$post = $result->fetch_assoc();

// Increment views
$update_views = $conn->prepare("UPDATE posts SET views = views + 1 WHERE id = ?");
$update_views->bind_param("i", $post['id']);
$update_views->execute();
$update_views->close();

$stmt->close();

// Get related posts
$related_posts = $conn->prepare("
    SELECT id, title, slug, excerpt, featured_image, published_at 
    FROM posts 
    WHERE status = 'published' AND author_id = ? AND id != ?
    ORDER BY published_at DESC
    LIMIT 3
");
$related_posts->bind_param("ii", $post['author_id'], $post['id']);
$related_posts->execute();
$related_result = $related_posts->get_result();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($post['title']); ?> - <?php echo APP_NAME; ?></title>
    <link rel="stylesheet" href="../assets/css/styles.css">
</head>
<body>
    <div class="top-navbar">
        <h1><?php echo APP_NAME; ?></h1>
        <div class="top-navbar-menu">
            <a href="index.php">Home</a>
            <a href="search.php">Search</a>
            <a href="../login.php" class="btn-login">Login</a>
        </div>
    </div>
    
    <div class="public-container">
        <a href="index.php" class="back-link">← Back to All Posts</a>
        
        <article>
            <!-- Article Header -->
            <div class="article-header">
                <h1><?php echo htmlspecialchars($post['title']); ?></h1>
                
                <div class="article-meta">
                    <span>By <strong><?php echo htmlspecialchars($post['username']); ?></strong></span>
                    <span><?php echo date('F d, Y', strtotime($post['published_at'])); ?></span>
                    <span><?php echo $post['views']; ?> views</span>
                </div>
            </div>
            
            <!-- Featured Image -->
            <?php if (!empty($post['featured_image'])): ?>
                <img src="../uploads/posts/<?php echo htmlspecialchars($post['featured_image']); ?>" alt="<?php echo htmlspecialchars($post['title']); ?>" class="featured-image">
            <?php endif; ?>
            
            <!-- Article Content -->
            <div class="article-content">
                <?php echo nl2br(htmlspecialchars($post['content'])); ?>
            </div>
            
            <!-- Reactions Section (Likes & Dislikes) -->
            <div class="reactions-section">
                <span style="color: #b0b3b8; font-weight: 600;">Was this helpful?</span>
                <button class="reaction-btn" onclick="toggleReaction(<?php echo $post['id']; ?>, 'like')" id="like-btn" title="Like this post">
                    👍 <span class="reaction-count" id="like-count"><?php echo intval($post['likes']); ?></span>
                </button>
                <button class="reaction-btn" onclick="toggleReaction(<?php echo $post['id']; ?>, 'dislike')" id="dislike-btn" title="Dislike this post">
                    👎 <span class="reaction-count" id="dislike-count"><?php echo intval($post['dislikes']); ?></span>
                </button>
            </div>
        </article>
        
        <!-- Comments Section -->
        <div class="comments-section">
            <h3>💬 Comments</h3>
            
            <!-- Comment Form -->
            <div class="comment-form">
                <h4>Leave a Comment</h4>
                <form id="comment-form">
                    <div class="form-row">
                        <div class="form-group">
                            <label for="author_name">Your Name *</label>
                            <input type="text" id="author_name" name="author_name" maxlength="100" required>
                        </div>
                        <div class="form-group">
                            <label for="author_email">Email *</label>
                            <input type="email" id="author_email" name="author_email" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="comment_content">Comment * (max 1000 characters)</label>
                        <textarea id="comment_content" name="comment_content" maxlength="1000" required placeholder="Share your thoughts..."></textarea>
                    </div>
                    <button type="submit" class="comment-submit">Submit Comment</button>
                </form>
                <div id="comment-message"></div>
            </div>
            
            <!-- Comments List -->
            <div class="comments-list" id="comments-list">
                <div class="no-comments">Loading comments...</div>
            </div>
        </div>
        
        <!-- Related Posts -->
        <?php if ($related_result->num_rows > 0): ?>
            <div class="related-posts">
                <h3>More from <?php echo htmlspecialchars($post['username']); ?></h3>
                
                <div class="related-posts-grid">
                    <?php while ($related = $related_result->fetch_assoc()): ?>
                        <div class="related-card">
                            <?php if (!empty($related['featured_image'])): ?>
                                <img src="../uploads/posts/<?php echo htmlspecialchars($related['featured_image']); ?>" alt="<?php echo htmlspecialchars($related['title']); ?>" class="related-image">
                            <?php endif; ?>
                            <a href="post.php?slug=<?php echo urlencode($related['slug']); ?>">
                                <?php echo htmlspecialchars($related['title']); ?>
                            </a>
                            <div class="related-date">
                                <?php echo date('M d, Y', strtotime($related['published_at'])); ?>
                            </div>
                        </div>
                    <?php endwhile; ?>
                </div>
            </div>
        <?php endif; ?>
    </div>
    
    <div class="footer">
        <p>&copy; <?php echo date('Y'); ?> <?php echo APP_NAME; ?>. All rights reserved.</p>
    </div>
    
    <!-- JavaScript for Reactions and Comments -->
    <script>
        const postId = <?php echo $post['id']; ?>;
        
        // Initialize on page load
        document.addEventListener('DOMContentLoaded', function() {
            loadReactions();
            loadComments();
            setupCommentForm();
        });
        
        /**
         * Toggle reaction (like/dislike)
         */
        function toggleReaction(postId, reaction) {
            const url = `../public/api/reactions.php?action=toggle&post_id=${postId}&reaction=${reaction}`;
            
            fetch(url)
                .then(response => {
                    if (!response.ok) throw new Error('Network response was not ok');
                    return response.json();
                })
                .then(data => {
                    if (data.success) {
                        loadReactions();
                    } else {
                        console.error('Error:', data.error);
                    }
                })
                .catch(error => {
                    console.error('Fetch error:', error);
                });
        }
        
        /**
         * Load current reactions
         */
        function loadReactions() {
            const url = `../public/api/reactions.php?action=get&post_id=${postId}`;
            
            fetch(url)
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        // Update counts
                        document.getElementById('like-count').textContent = data.likes;
                        document.getElementById('dislike-count').textContent = data.dislikes;
                        
                        // Update button active states
                        document.getElementById('like-btn').classList.remove('active');
                        document.getElementById('dislike-btn').classList.remove('active');
                        
                        if (data.user_reaction === 'like') {
                            document.getElementById('like-btn').classList.add('active');
                        } else if (data.user_reaction === 'dislike') {
                            document.getElementById('dislike-btn').classList.add('active');
                        }
                    }
                })
                .catch(error => console.error('Error loading reactions:', error));
        }
        
        /**
         * Load all approved comments
         */
        function loadComments() {
            const url = `../public/api/comments.php?action=get&post_id=${postId}`;
            
            fetch(url)
                .then(response => response.json())
                .then(data => {
                    const commentsList = document.getElementById('comments-list');
                    
                    if (!data.success) {
                        commentsList.innerHTML = '<div class="no-comments">Error loading comments</div>';
                        return;
                    }
                    
                    if (data.comments.length === 0) {
                        commentsList.innerHTML = '<div class="no-comments">No comments yet. Be the first to comment!</div>';
                        return;
                    }
                    
                    // Build comments HTML
                    let html = '';
                    data.comments.forEach(comment => {
                        html += `
                            <div class="comment-item">
                                <div class="comment-header">
                                    <span class="comment-author">${comment.author}</span>
                                    <span class="comment-date">${comment.date}</span>
                                </div>
                                <div class="comment-content">${comment.content}</div>
                            </div>
                        `;
                    });
                    
                    commentsList.innerHTML = html;
                })
                .catch(error => {
                    console.error('Error loading comments:', error);
                    document.getElementById('comments-list').innerHTML = '<div class="no-comments">Error loading comments</div>';
                });
        }
        
        /**
         * Setup comment form submission
         */
        function setupCommentForm() {
            document.getElementById('comment-form').addEventListener('submit', function(e) {
                e.preventDefault();
                
                const authorName = document.getElementById('author_name').value.trim();
                const authorEmail = document.getElementById('author_email').value.trim();
                const content = document.getElementById('comment_content').value.trim();
                
                // Validate on client side too
                if (!authorName) {
                    showMessage('Name is required', 'error');
                    return;
                }
                if (!authorEmail) {
                    showMessage('Email is required', 'error');
                    return;
                }
                if (!content) {
                    showMessage('Comment cannot be empty', 'error');
                    return;
                }
                
                // Prepare form data
                const formData = new FormData();
                formData.append('author_name', authorName);
                formData.append('author_email', authorEmail);
                formData.append('content', content);
                
                // Submit comment
                const url = `../public/api/comments.php?action=add&post_id=${postId}`;
                
                fetch(url, {
                    method: 'POST',
                    body: formData
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        showMessage(data.message, 'success');
                        document.getElementById('comment-form').reset();
                        // Reload comments after a delay
                        setTimeout(() => loadComments(), 1500);
                    } else {
                        showMessage(data.error, 'error');
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    showMessage('Failed to submit comment', 'error');
                });
            });
        }
        
        /**
         * Display message
         */
        function showMessage(message, type) {
            const messageBox = document.getElementById('comment-message');
            const className = type === 'success' ? 'message-success' : 'message-error';
            messageBox.innerHTML = `<div class="message-box ${className}">${message}</div>`;
            
            // Auto hide after 5 seconds
            setTimeout(() => {
                messageBox.innerHTML = '';
            }, 5000);
        }
    </script>
</body>
</html>
