-- ============================================================
-- BLOG CMS - COMPLETE DATABASE SETUP
-- Run this in phpMyAdmin SQL tab
-- ============================================================

-- Create Database
CREATE DATABASE IF NOT EXISTS `blog_cms` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `blog_cms`;

-- ============================================================
-- TABLE 1: USERS
-- ============================================================
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` enum('admin','author') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'author',
  `status` enum('active','inactive','blocked') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`),
  KEY `role` (`role`),
  KEY `status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABLE 2: POSTS
-- ============================================================
CREATE TABLE `posts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `author_id` int(11) NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `excerpt` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `featured_image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `views` int(11) DEFAULT 0,
  `likes` int(11) DEFAULT 0,
  `dislikes` int(11) DEFAULT 0,
  `status` enum('draft','published','archived') COLLATE utf8mb4_unicode_ci DEFAULT 'draft',
  `published_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`),
  KEY `author_id` (`author_id`),
  KEY `status` (`status`),
  KEY `published_at` (`published_at`),
  CONSTRAINT `posts_ibfk_1` FOREIGN KEY (`author_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABLE 3: POST REACTIONS (Likes & Dislikes)
-- ============================================================
CREATE TABLE `post_reactions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `post_id` int(11) NOT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `reaction` enum('like','dislike') COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_reaction` (`post_id`,`ip_address`),
  KEY `post_id` (`post_id`),
  KEY `ip_address` (`ip_address`),
  CONSTRAINT `post_reactions_ibfk_1` FOREIGN KEY (`post_id`) REFERENCES `posts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABLE 4: POST COMMENTS
-- ============================================================
CREATE TABLE `post_comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `post_id` int(11) NOT NULL,
  `author_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `author_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('pending','approved','rejected') COLLATE utf8mb4_unicode_ci DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `post_id` (`post_id`),
  KEY `status` (`status`),
  KEY `author_email` (`author_email`),
  CONSTRAINT `post_comments_ibfk_1` FOREIGN KEY (`post_id`) REFERENCES `posts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- TABLE 5: ACTIVITY LOGS
-- ============================================================
CREATE TABLE `activity_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `action` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `action` (`action`),
  KEY `created_at` (`created_at`),
  CONSTRAINT `activity_logs_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- INSERT ADMIN USER
-- Password: admin123
-- ============================================================
INSERT INTO `users` (`username`, `email`, `password`, `role`, `status`) VALUES
('admin', 'admin@blog.com', '$2y$10$YIjlrPnoS3q7Q3V8G8DLe.0Y5XVVAech8X3SNWWu0SHGELslmOH.C', 'admin', 'active');

-- ============================================================
-- INSERT SAMPLE AUTHORS
-- Password: admin123
-- ============================================================
INSERT INTO `users` (`username`, `email`, `password`, `role`, `status`) VALUES
('author1', 'author1@blog.com', '$2y$10$YIjlrPnoS3q7Q3V8G8DLe.0Y5XVVAech8X3SNWWu0SHGELslmOH.C', 'author', 'active'),
('author2', 'author2@blog.com', '$2y$10$YIjlrPnoS3q7Q3V8G8DLe.0Y5XVVAech8X3SNWWu0SHGELslmOH.C', 'author', 'active');

-- ============================================================
-- INSERT SAMPLE POSTS
-- ============================================================
INSERT INTO `posts` (`author_id`, `title`, `slug`, `content`, `excerpt`, `status`, `published_at`) VALUES
(2, 'Getting Started with Web Development', 'getting-started-web-development', 'Web development is a comprehensive field that combines design, backend programming, and frontend technologies. This guide will help you understand the basics and get started on your journey.\n\nKey topics covered:\n- HTML Basics\n- CSS Styling\n- JavaScript Fundamentals\n- Responsive Design\n- Backend Integration', 'Learn the fundamentals of web development from scratch', 'published', NOW()),
(2, 'Advanced PHP Techniques', 'advanced-php-techniques', 'PHP is a powerful server-side language that powers millions of websites. In this comprehensive guide, we will explore advanced techniques and best practices.\n\nWe will cover:\n- OOP Concepts\n- Design Patterns\n- Performance Optimization\n- Security Best Practices\n- Testing and Debugging', 'Master advanced PHP programming concepts', 'published', NOW() - INTERVAL 2 DAY),
(3, 'Database Design Best Practices', 'database-design-best-practices', 'Proper database design is crucial for scalable applications. Learn how to design databases that perform well and maintain data integrity.\n\nTopics include:\n- Normalization\n- Indexing Strategies\n- Query Optimization\n- Data Relationships\n- Backup Strategies', 'Optimize your database design for performance', 'published', NOW() - INTERVAL 5 DAY);

-- ============================================================
-- INSERT SAMPLE COMMENTS
-- ============================================================
INSERT INTO `post_comments` (`post_id`, `author_name`, `author_email`, `content`, `ip_address`, `status`) VALUES
(1, 'John Smith', 'john@example.com', 'Great tutorial! Very helpful for beginners like me.', '192.168.1.1', 'approved'),
(1, 'Sarah Johnson', 'sarah@example.com', 'Can you explain more about responsive design?', '192.168.1.2', 'pending'),
(2, 'Mike Davis', 'mike@example.com', 'Excellent coverage of PHP best practices. Thanks!', '192.168.1.3', 'approved'),
(3, 'Emily Brown', 'emily@example.com', 'Very informative article about database optimization.', '192.168.1.4', 'approved');

-- ============================================================
-- INSERT SAMPLE REACTIONS
-- ============================================================
INSERT INTO `post_reactions` (`post_id`, `ip_address`, `reaction`) VALUES
(1, '192.168.1.10', 'like'),
(1, '192.168.1.11', 'like'),
(1, '192.168.1.12', 'like'),
(2, '192.168.1.13', 'like'),
(2, '192.168.1.14', 'dislike'),
(3, '192.168.1.15', 'like');

-- ============================================================
-- DATABASE CREATED SUCCESSFULLY!
-- ============================================================
